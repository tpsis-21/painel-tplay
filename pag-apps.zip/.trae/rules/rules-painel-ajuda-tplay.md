Painel de Ajuda - TopPlay
home (store): ajuda.tplay21.in 
painel: ajuda.tplay21.in/painel
pagina de apps: ajuda.tplay21.in
pagina de video tutoriais: ajuda.tplay21.in/tutorial


No painel deve ser possivel criar paginas como a do template para aplicativos com informações de download e instalação para diferentes dispositivos, assim como tutoriais em video, fortos da interface, logo do app etc, seguindo as boas praticas de design.
na home nós vamos ter uma especie de loja de apps (com os apps que forem configurados pra ficar visiveis nela)